<h1>Versions</h1>

<p align="justify">The authors of the main version are:</p>

<ul>
  <li><a href="http://lattes.cnpq.br/2268506213083114" target="_blank">Prof. Wanderlei Malaquias Pereira Junior</a></li>
  <li><a href="http://lattes.cnpq.br/6429652195589650" target="_blank">Civil eng. Murilo Carneiro Rodrigues</a></li>
  <li><a href="http://lattes.cnpq.br/2749614068229103" target="_blank">Civil eng. José Vitor Silva de Carvalho</a></li>
  <li><a href="http://lattes.cnpq.br/3425218766628116" target="_blank">Civil eng. Gabriel Bernardes de Carvalho</a></li>
  <li><a href="http://lattes.cnpq.br/8465474056220474" target="_blank">Civil eng. Matheus Henrique Morato de Moraes</a></li>
  <li><a href="http://lattes.cnpq.br/0067281135180613" target="_blank">Prof. Marcos Napoleão Rabelo</a></li>
  <li><a href="http://lattes.cnpq.br/6573703999085753" target="_blank">Prof. Davidson de Oliveira França Junior</a></li>
</ul>   

<p align="justify">You can also see the <a href="https://pypi.org/project/FINITO-TOOLBOX/#history" target="_blank">release history</a>.</p>

<h4><i>Version 2022.2</i></h4>

<h5>Project team</h5>

<ol>
    <li><a href="http://lattes.cnpq.br/2268506213083114" target="_blank">Prof. Wanderlei Malaquias Pereira Junior</a></li>
    <li><a href="http://lattes.cnpq.br/8801080897723883" target="_blank">Prof. Daniel de Lima Araújo</a></li>
    <li><a href="http://lattes.cnpq.br/9338133936544461" target="_blank">Civil eng. Jerônimo Santiago Alves Arantes</a></li>
    <li><a href="http://lattes.cnpq.br/0848471235975975" target="_blank">Civil eng. Efraim Soares Bernardes</a></li>
</ol> 

<ol>
  <li><p align="justify">Frame elements bugs;</p></li>
  <li><p align="justify">Distributed load in frame element.</p></li>
</ol> 

<h4><i>Version 2022.1</i></h4>

<ol>
  <li><p align="justify">Frame element.</p></li>
</ol> 